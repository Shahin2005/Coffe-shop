﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class order
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.quantity1 = New System.Windows.Forms.NumericUpDown()
        Me.quantity2 = New System.Windows.Forms.NumericUpDown()
        Me.quantity3 = New System.Windows.Forms.NumericUpDown()
        Me.quantity4 = New System.Windows.Forms.NumericUpDown()
        Me.quantity5 = New System.Windows.Forms.NumericUpDown()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.item1 = New System.Windows.Forms.ComboBox()
        Me.txtordernum = New System.Windows.Forms.NumericUpDown()
        Me.item2 = New System.Windows.Forms.ComboBox()
        Me.item3 = New System.Windows.Forms.ComboBox()
        Me.item4 = New System.Windows.Forms.ComboBox()
        Me.item5 = New System.Windows.Forms.ComboBox()
        Me.custom1 = New System.Windows.Forms.CheckBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.custom5 = New System.Windows.Forms.CheckBox()
        Me.custom4 = New System.Windows.Forms.CheckBox()
        Me.custom3 = New System.Windows.Forms.CheckBox()
        Me.custom2 = New System.Windows.Forms.CheckBox()
        Me.txttotal = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txttotal2 = New System.Windows.Forms.TextBox()
        CType(Me.quantity1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.quantity2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.quantity3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.quantity4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.quantity5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.txtordernum, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'quantity1
        '
        Me.quantity1.Location = New System.Drawing.Point(186, 60)
        Me.quantity1.Margin = New System.Windows.Forms.Padding(2)
        Me.quantity1.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.quantity1.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.quantity1.Name = "quantity1"
        Me.quantity1.Size = New System.Drawing.Size(37, 20)
        Me.quantity1.TabIndex = 220
        Me.quantity1.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'quantity2
        '
        Me.quantity2.Location = New System.Drawing.Point(186, 94)
        Me.quantity2.Margin = New System.Windows.Forms.Padding(2)
        Me.quantity2.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.quantity2.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.quantity2.Name = "quantity2"
        Me.quantity2.Size = New System.Drawing.Size(37, 20)
        Me.quantity2.TabIndex = 219
        Me.quantity2.Value = New Decimal(New Integer() {1, 0, 0, 0})
        Me.quantity2.Visible = False
        '
        'quantity3
        '
        Me.quantity3.Location = New System.Drawing.Point(186, 126)
        Me.quantity3.Margin = New System.Windows.Forms.Padding(2)
        Me.quantity3.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.quantity3.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.quantity3.Name = "quantity3"
        Me.quantity3.Size = New System.Drawing.Size(37, 20)
        Me.quantity3.TabIndex = 218
        Me.quantity3.Value = New Decimal(New Integer() {1, 0, 0, 0})
        Me.quantity3.Visible = False
        '
        'quantity4
        '
        Me.quantity4.Location = New System.Drawing.Point(186, 159)
        Me.quantity4.Margin = New System.Windows.Forms.Padding(2)
        Me.quantity4.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.quantity4.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.quantity4.Name = "quantity4"
        Me.quantity4.Size = New System.Drawing.Size(37, 20)
        Me.quantity4.TabIndex = 217
        Me.quantity4.Value = New Decimal(New Integer() {1, 0, 0, 0})
        Me.quantity4.Visible = False
        '
        'quantity5
        '
        Me.quantity5.Location = New System.Drawing.Point(186, 191)
        Me.quantity5.Margin = New System.Windows.Forms.Padding(2)
        Me.quantity5.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.quantity5.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.quantity5.Name = "quantity5"
        Me.quantity5.Size = New System.Drawing.Size(37, 20)
        Me.quantity5.TabIndex = 216
        Me.quantity5.Value = New Decimal(New Integer() {1, 0, 0, 0})
        Me.quantity5.Visible = False
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(289, 34)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(176, 20)
        Me.Label18.TabIndex = 215
        Me.Label18.Text = "customise your order"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.ListBox1)
        Me.GroupBox1.Controls.Add(Me.RadioButton2)
        Me.GroupBox1.Controls.Add(Me.RadioButton1)
        Me.GroupBox1.Location = New System.Drawing.Point(22, 230)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Size = New System.Drawing.Size(201, 81)
        Me.GroupBox1.TabIndex = 211
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Collection or Delivery"
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Items.AddRange(New Object() {"House", "Work"})
        Me.ListBox1.Location = New System.Drawing.Point(127, 46)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(69, 30)
        Me.ListBox1.TabIndex = 238
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(16, 47)
        Me.RadioButton2.Margin = New System.Windows.Forms.Padding(2)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(107, 17)
        Me.RadioButton2.TabIndex = 1
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "Delivery(£1 extra)"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Location = New System.Drawing.Point(16, 26)
        Me.RadioButton1.Margin = New System.Windows.Forms.Padding(2)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(71, 17)
        Me.RadioButton1.TabIndex = 0
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Collection"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Button2.Location = New System.Drawing.Point(35, 316)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(135, 61)
        Me.Button2.TabIndex = 210
        Me.Button2.Text = "Submit order"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(10, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(148, 20)
        Me.Label3.TabIndex = 209
        Me.Label3.Text = "Number of orders"
        '
        'item1
        '
        Me.item1.FormattingEnabled = True
        Me.item1.Items.AddRange(New Object() {"Hot Chocolate(£2.50)", "Cappuccino(£3.00)", "Water(£1.00)", "Latte(£2.50)", "Espresso(£2.00)", "Iced Coffee(£3.00)", "Chocolate cake(£2.00)"})
        Me.item1.Location = New System.Drawing.Point(22, 61)
        Me.item1.Name = "item1"
        Me.item1.Size = New System.Drawing.Size(148, 21)
        Me.item1.TabIndex = 222
        '
        'txtordernum
        '
        Me.txtordernum.Location = New System.Drawing.Point(163, 16)
        Me.txtordernum.Margin = New System.Windows.Forms.Padding(2)
        Me.txtordernum.Maximum = New Decimal(New Integer() {5, 0, 0, 0})
        Me.txtordernum.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.txtordernum.Name = "txtordernum"
        Me.txtordernum.Size = New System.Drawing.Size(29, 20)
        Me.txtordernum.TabIndex = 223
        Me.txtordernum.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'item2
        '
        Me.item2.FormattingEnabled = True
        Me.item2.Items.AddRange(New Object() {"Hot Chocolate(£2.50)", "Cappuccino(£3.00)", "Water(£1.00)", "Latte(£2.50)", "Espresso(£2.00)", "Iced Coffee(£3.00)", "Chocolate cake(£2.00)"})
        Me.item2.Location = New System.Drawing.Point(22, 94)
        Me.item2.Name = "item2"
        Me.item2.Size = New System.Drawing.Size(148, 21)
        Me.item2.TabIndex = 224
        Me.item2.Visible = False
        '
        'item3
        '
        Me.item3.FormattingEnabled = True
        Me.item3.Items.AddRange(New Object() {"Hot Chocolate(£2.50)", "Cappuccino(£3.00)", "Water(£1.00)", "Latte(£2.50)", "Espresso(£2.00)", "Iced Coffee(£3.00)", "Chocolate cake(£2.00)"})
        Me.item3.Location = New System.Drawing.Point(22, 126)
        Me.item3.Name = "item3"
        Me.item3.Size = New System.Drawing.Size(148, 21)
        Me.item3.TabIndex = 225
        Me.item3.Visible = False
        '
        'item4
        '
        Me.item4.FormattingEnabled = True
        Me.item4.Items.AddRange(New Object() {"Hot Chocolate(£2.50)", "Cappuccino(£3.00)", "Water(£1.00)", "Latte(£2.50)", "Espresso(£2.00)", "Iced Coffee(£3.00)", "Chocolate cake(£2.00)"})
        Me.item4.Location = New System.Drawing.Point(22, 159)
        Me.item4.Name = "item4"
        Me.item4.Size = New System.Drawing.Size(148, 21)
        Me.item4.TabIndex = 226
        Me.item4.Visible = False
        '
        'item5
        '
        Me.item5.FormattingEnabled = True
        Me.item5.Items.AddRange(New Object() {"Hot Chocolate(£2.50)", "Cappuccino(£3.00)", "Water(£1.00)", "Latte(£2.50)", "Espresso(£2.00)", "Iced Coffee(£3.00)", "Chocolate cake(£2.00)"})
        Me.item5.Location = New System.Drawing.Point(22, 189)
        Me.item5.Name = "item5"
        Me.item5.Size = New System.Drawing.Size(148, 21)
        Me.item5.TabIndex = 227
        Me.item5.Visible = False
        '
        'custom1
        '
        Me.custom1.AutoSize = True
        Me.custom1.Location = New System.Drawing.Point(4, 25)
        Me.custom1.Margin = New System.Windows.Forms.Padding(2)
        Me.custom1.Name = "custom1"
        Me.custom1.Size = New System.Drawing.Size(102, 17)
        Me.custom1.TabIndex = 228
        Me.custom1.Text = "Whipped Cream"
        Me.custom1.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.custom5)
        Me.GroupBox2.Controls.Add(Me.custom4)
        Me.GroupBox2.Controls.Add(Me.custom3)
        Me.GroupBox2.Controls.Add(Me.custom2)
        Me.GroupBox2.Controls.Add(Me.custom1)
        Me.GroupBox2.Location = New System.Drawing.Point(293, 56)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Size = New System.Drawing.Size(172, 137)
        Me.GroupBox2.TabIndex = 229
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Customise (extra 50p for each)"
        '
        'custom5
        '
        Me.custom5.AutoSize = True
        Me.custom5.Location = New System.Drawing.Point(4, 109)
        Me.custom5.Margin = New System.Windows.Forms.Padding(2)
        Me.custom5.Name = "custom5"
        Me.custom5.Size = New System.Drawing.Size(91, 17)
        Me.custom5.TabIndex = 232
        Me.custom5.Text = "marshmallows"
        Me.custom5.UseVisualStyleBackColor = True
        '
        'custom4
        '
        Me.custom4.AutoSize = True
        Me.custom4.Location = New System.Drawing.Point(4, 88)
        Me.custom4.Margin = New System.Windows.Forms.Padding(2)
        Me.custom4.Name = "custom4"
        Me.custom4.Size = New System.Drawing.Size(67, 17)
        Me.custom4.TabIndex = 231
        Me.custom4.Text = "sprinkles"
        Me.custom4.UseVisualStyleBackColor = True
        '
        'custom3
        '
        Me.custom3.AutoSize = True
        Me.custom3.Location = New System.Drawing.Point(4, 66)
        Me.custom3.Margin = New System.Windows.Forms.Padding(2)
        Me.custom3.Name = "custom3"
        Me.custom3.Size = New System.Drawing.Size(95, 17)
        Me.custom3.TabIndex = 230
        Me.custom3.Text = "caramel sauce"
        Me.custom3.UseVisualStyleBackColor = True
        '
        'custom2
        '
        Me.custom2.AutoSize = True
        Me.custom2.Location = New System.Drawing.Point(4, 46)
        Me.custom2.Margin = New System.Windows.Forms.Padding(2)
        Me.custom2.Name = "custom2"
        Me.custom2.Size = New System.Drawing.Size(105, 17)
        Me.custom2.TabIndex = 229
        Me.custom2.Text = "chocolate sauce"
        Me.custom2.UseVisualStyleBackColor = True
        '
        'txttotal
        '
        Me.txttotal.Location = New System.Drawing.Point(352, 230)
        Me.txttotal.Name = "txttotal"
        Me.txttotal.Size = New System.Drawing.Size(100, 20)
        Me.txttotal.TabIndex = 233
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(0, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 234
        Me.Label1.Text = "Label1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(262, 233)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(84, 13)
        Me.Label2.TabIndex = 235
        Me.Label2.Text = "total before VAT"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(271, 260)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(75, 13)
        Me.Label4.TabIndex = 237
        Me.Label4.Text = "total after VAT"
        '
        'txttotal2
        '
        Me.txttotal2.Location = New System.Drawing.Point(352, 257)
        Me.txttotal2.Name = "txttotal2"
        Me.txttotal2.Size = New System.Drawing.Size(100, 20)
        Me.txttotal2.TabIndex = 236
        '
        'order
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(532, 409)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txttotal2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txttotal)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.item5)
        Me.Controls.Add(Me.item4)
        Me.Controls.Add(Me.item3)
        Me.Controls.Add(Me.item2)
        Me.Controls.Add(Me.txtordernum)
        Me.Controls.Add(Me.item1)
        Me.Controls.Add(Me.quantity1)
        Me.Controls.Add(Me.quantity2)
        Me.Controls.Add(Me.quantity3)
        Me.Controls.Add(Me.quantity4)
        Me.Controls.Add(Me.quantity5)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label3)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "order"
        CType(Me.quantity1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.quantity2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.quantity3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.quantity4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.quantity5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.txtordernum, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents quantity1 As NumericUpDown
    Friend WithEvents quantity2 As NumericUpDown
    Friend WithEvents quantity3 As NumericUpDown
    Friend WithEvents quantity4 As NumericUpDown
    Friend WithEvents quantity5 As NumericUpDown
    Friend WithEvents Label18 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents RadioButton2 As RadioButton
    Friend WithEvents RadioButton1 As RadioButton
    Friend WithEvents Button2 As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents item1 As ComboBox
    Friend WithEvents txtordernum As NumericUpDown
    Friend WithEvents item2 As ComboBox
    Friend WithEvents item3 As ComboBox
    Friend WithEvents item4 As ComboBox
    Friend WithEvents item5 As ComboBox
    Friend WithEvents custom1 As CheckBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents custom5 As CheckBox
    Friend WithEvents custom4 As CheckBox
    Friend WithEvents custom3 As CheckBox
    Friend WithEvents custom2 As CheckBox
    Friend WithEvents txttotal As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txttotal2 As TextBox
    Friend WithEvents ListBox1 As ListBox
End Class
