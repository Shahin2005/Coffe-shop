﻿Module variables
    Public cost As Single 'these are global variables that are used in the forms
    Public items(4), orders(4) As String
    Public quantity(4) As String
    Public delivery As String
    Public Const vat As Single = 6 / 5
    Public quantity1, quantity2, quantity3, quantity4, quantity5, txtVAT, txtVAT2, paid, change, RadioButton1, RadioButton2, delvadd, address As String
    Public ComboBox1, ComboBox2, ComboBox3, satisfied, reciept, phonenum, dicode, itemcost(4), orderreceipt As String
    Public refnum1, fname, title, sname, month, day, DOB, orderline(4) As String
    Public totalcost(4) As Single
End Module
