﻿Public Class receipt
    Private Sub receipt_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtreceipt.Text = reciept ' outputs the receipt into the textbox
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Do
            satisfied = UCase(InputBox("Did you like our services(Y/N)?")) 'ask the user for their opinions on the service
            If Asc(satisfied) = 89 Or Asc(satisfied) = 78 Then    'this is a lookup check as is the cutomers answer is only a Y or N
                MsgBox("thank you for your feedback")
            Else MsgBox("Please enter a valid answer")
                If cost > 10 And UCase(satisfied) = "Y" Then
                    MsgBox("Thank you for your feedback and we look forward to see you soon")
                End If
            End If

        Loop Until Asc(satisfied) = 89 Or Asc(satisfied) = 78

    End Sub


End Class