﻿Public Class order
    Public Structure orders
        Dim quantity As Integer
        Dim cost As Single
        Dim item As String
    End Structure
    Private Sub ordernum_TextChanged(sender As Object, e As EventArgs) Handles txtordernum.TextChanged
        ' these lines checl to see how many orders the customer wants.
        Select Case txtordernum.Text
            Case 1
                item1.Visible = True
                quantity1.Visible = True
                item2.Visible = False
                quantity2.Visible = False
                item3.Visible = False
                quantity3.Visible = False
                item4.Visible = False
                quantity4.Visible = False
                item5.Visible = False
                quantity5.Visible = False
            Case 2
                item2.Visible = True
                quantity2.Visible = True
                item3.Visible = False
                quantity3.Visible = False
                item4.Visible = False
                quantity4.Visible = False
                item5.Visible = False
                quantity5.Visible = False
            Case 3
                item3.Visible = True
                quantity3.Visible = True
                item4.Visible = False
                quantity4.Visible = False
                item5.Visible = False
                quantity5.Visible = False
            Case 4
                item4.Visible = True
                quantity4.Visible = True
                item5.Visible = False
                quantity5.Visible = False
            Case 5
                item5.Visible = True
                quantity5.Visible = True
        End Select
    End Sub
    Function applyVAT(ByRef cost) ' this function apply VAT to the total cost.
        cost = cost * 1.2
        applyVAT = cost
    End Function
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim ordernum(4) As orders
        'these lines store the order description, unit price and quantity into an record
        If item1.Text = "Hot Chocolate(£2.50)" Then
            ordernum(0).item = "Hot chocolate"
            ordernum(0).quantity = quantity1.Text
            orderline(0) = ordernum(0).item & " :" & ordernum(0).quantity
            ordernum(0).cost = 2.5
        ElseIf item1.Text = "Cappuccino(£3.00)" Then
            ordernum(0).item = "Cappuccino"
            ordernum(0).quantity = quantity1.Text
            orderline(0) = ordernum(0).item & " :" & ordernum(0).quantity
            ordernum(0).cost = 3
        ElseIf item1.Text = "Water(£1.00)" Then
            ordernum(0).item = "Water"
            ordernum(0).quantity = quantity1.Text
            orderline(0) = ordernum(0).item & " :" & ordernum(0).quantity
            ordernum(0).cost = 1
        ElseIf item1.Text = "Latte(£2.50)" Then
            ordernum(0).item = "Latte"
            ordernum(0).quantity = quantity1.Text
            orderline(0) = ordernum(0).item & " :" & ordernum(0).quantity
            ordernum(0).cost = 2.5
        ElseIf item1.Text = "Chocolate cake(£2.00)" Then
            ordernum(0).item = "Chocolate cake"
            ordernum(0).quantity = quantity1.Text
            orderline(0) = ordernum(0).item & " :" & ordernum(0).quantity
            ordernum(0).cost = 2
        ElseIf item1.Text = "Iced Coffee(£3.00)" Then
            ordernum(0).item = "Iced Coffee"
            ordernum(0).quantity = quantity1.Text
            orderline(0) = ordernum(0).item & " :" & ordernum(0).quantity
            ordernum(0).cost = 3
        ElseIf item1.Text = "Espresso(£2.00)" Then
            ordernum(0).item = "Espresso"
            ordernum(0).quantity = quantity1.Text
            orderline(0) = ordernum(0).item & " :" & ordernum(0).quantity
            ordernum(0).cost = 2
        End If

        If item2.Text = "Hot Chocolate(£2.50)" Then
            ordernum(1).item = "Hot chocolate"
            ordernum(1).quantity = quantity2.Text
            orderline(1) = ordernum(1).item & " :" & ordernum(1).quantity
            ordernum(1).cost = 2.5
        ElseIf item2.Text = "Cappuccino(£3.00)" Then
            ordernum(1).item = "Cappuccino"
            ordernum(1).quantity = quantity2.Text
            orderline(1) = ordernum(1).item & " :" & ordernum(1).quantity
            ordernum(1).cost = 3
        ElseIf item2.Text = "Water(£1.00)" Then
            ordernum(1).item = "Water"
            ordernum(1).quantity = quantity2.Text
            orderline(1) = ordernum(1).item & " :" & ordernum(1).quantity
            ordernum(1).cost = 1
        ElseIf item2.Text = "Latte(£2.50)" Then
            ordernum(1).item = "Latte"
            ordernum(1).quantity = quantity2.Text
            orderline(1) = ordernum(1).item & " :" & ordernum(1).quantity
            ordernum(1).cost = 2.5
        ElseIf item2.Text = "Chocolate cake(£2.00)" Then
            ordernum(1).item = "Chocolate cake"
            ordernum(1).quantity = quantity2.Text
            orderline(1) = ordernum(1).item & " :" & ordernum(1).quantity
            ordernum(1).cost = 2
        ElseIf item2.Text = "Iced Coffee(£3.00)" Then
            ordernum(1).item = "Iced Coffee"
            ordernum(1).quantity = quantity2.Text
            orderline(1) = ordernum(1).item & " :" & ordernum(1).quantity
            ordernum(1).cost = 3
        ElseIf item2.Text = "Espresso(£2.00)" Then
            ordernum(1).item = "Espresso"
            ordernum(1).quantity = quantity2.Text
            orderline(1) = ordernum(1).item & " :" & ordernum(1).quantity
            ordernum(1).cost = 2
        End If

        If item3.Text = "Hot Chocolate(£2.50)" Then
            ordernum(2).item = "Hot chocolate"
            ordernum(2).quantity = quantity3.Text
            orderline(2) = ordernum(2).item & " :" & ordernum(2).quantity
            ordernum(2).cost = 2.5
        ElseIf item3.Text = "Cappuccino(£3.00)" Then
            ordernum(2).item = "Cappuccino"
            ordernum(2).quantity = quantity3.Text
            orderline(2) = ordernum(2).item & " :" & ordernum(2).quantity
            ordernum(2).cost = 3
        ElseIf item3.Text = "Water(£1.00)" Then
            ordernum(2).item = "Water"
            ordernum(2).quantity = quantity3.Text
            orderline(2) = ordernum(2).item & " :" & ordernum(2).quantity
            ordernum(2).cost = 1
        ElseIf item3.Text = "Latte(£2.50)" Then
            ordernum(2).item = "Latte"
            ordernum(2).quantity = quantity3.Text
            orderline(2) = ordernum(2).item & " :" & ordernum(2).quantity
            ordernum(2).cost = 2.5
        ElseIf item3.Text = "Chocolate cake(£2.00)" Then
            ordernum(2).item = "Chocolate cake"
            ordernum(2).quantity = quantity3.Text
            orderline(2) = ordernum(2).item & " :" & ordernum(2).quantity
            ordernum(2).cost = 2
        ElseIf item3.Text = "Iced Coffee(£3.00)" Then
            ordernum(2).item = "Iced Coffee"
            ordernum(2).quantity = quantity3.Text
            orderline(2) = ordernum(2).item & " :" & ordernum(2).quantity
            ordernum(2).cost = 3
        ElseIf item3.Text = "Espresso(£2.00)" Then
            ordernum(2).item = "Espresso"
            ordernum(2).quantity = quantity3.Text
            orderline(2) = ordernum(2).item & " :" & ordernum(2).quantity
            ordernum(2).cost = 2
        End If

        If item4.Text = "Hot Chocolate(£2.50)" Then
            ordernum(3).item = "Hot chocolate"
            ordernum(3).quantity = quantity4.Text
            orderline(3) = ordernum(3).item & " :" & ordernum(3).quantity
            ordernum(3).cost = 2.5
        ElseIf item4.Text = "Cappuccino(£3.00)" Then
            ordernum(3).item = "Cappuccino"
            ordernum(3).quantity = quantity4.Text
            orderline(3) = ordernum(3).item & " :" & ordernum(3).quantity
            ordernum(3).cost = 3
        ElseIf item4.Text = "Water(£1.00)" Then
            ordernum(3).item = "Water"
            ordernum(3).quantity = quantity4.Text
            orderline(3) = ordernum(3).item & " :" & ordernum(3).quantity
            ordernum(3).cost = 1
        ElseIf item4.Text = "Latte(£2.50)" Then
            ordernum(3).item = "Latte"
            ordernum(3).quantity = quantity4.Text
            orderline(3) = ordernum(3).item & " :" & ordernum(3).quantity
            ordernum(3).cost = 2.5
        ElseIf item4.Text = "Chocolate cake(£2.00)" Then
            ordernum(3).item = "Chocolate cake"
            ordernum(3).quantity = quantity4.Text
            orderline(3) = ordernum(3).item & " :" & ordernum(3).quantity
            ordernum(3).cost = 2
        ElseIf item4.Text = "Iced Coffee(£3.00)" Then
            ordernum(3).item = "Iced Coffee"
            ordernum(3).quantity = quantity4.Text
            orderline(3) = ordernum(3).item & " :" & ordernum(3).quantity
            ordernum(3).cost = 3
        ElseIf item4.Text = "Espresso(£2.00)" Then
            ordernum(3).item = "Espresso"
            ordernum(3).quantity = quantity4.Text
            orderline(3) = ordernum(3).item & " :" & ordernum(3).quantity
            ordernum(3).cost = 2
        End If

        If item5.Text = "Hot Chocolate(£2.50)" Then
            ordernum(4).item = "Hot chocolate"
            ordernum(4).quantity = quantity5.Text
            orderline(4) = ordernum(4).item & " :" & ordernum(4).quantity
            ordernum(4).cost = 2.5
        ElseIf item5.Text = "Cappuccino(£3.00)" Then
            ordernum(4).item = "Cappuccino"
            ordernum(4).quantity = quantity5.Text
            orderline(4) = ordernum(4).item & " :" & ordernum(4).quantity
            ordernum(4).cost = 3
        ElseIf item5.Text = "Water(£1.00)" Then
            ordernum(4).item = "Water"
            ordernum(4).quantity = quantity5.Text
            orderline(4) = ordernum(4).item & " :" & ordernum(4).quantity
            ordernum(4).cost = 1
        ElseIf item5.Text = "Latte(£2.50)" Then
            ordernum(4).item = "Latte"
            ordernum(4).quantity = quantity5.Text
            orderline(4) = ordernum(4).item & " :" & ordernum(4).quantity
            ordernum(4).cost = 2.5
        ElseIf item5.Text = "Chocolate cake(£2.00)" Then
            ordernum(4).item = "Chocolate cake"
            ordernum(4).quantity = quantity5.Text
            orderline(4) = ordernum(4).item & " :" & ordernum(4).quantity
            ordernum(4).cost = 2
        ElseIf item5.Text = "Iced Coffee(£3.00)" Then
            ordernum(4).item = "Iced coffee"
            ordernum(4).quantity = quantity5.Text
            orderline(4) = ordernum(4).item & " :" & ordernum(4).quantity
            ordernum(4).cost = 3
        ElseIf item5.Text = "Espresso(£2.00)" Then
            ordernum(4).item = "Espresso"
            ordernum(4).quantity = quantity5.Text
            orderline(4) = ordernum(4).item & " :" & ordernum(4).quantity
            ordernum(4).cost = 2
        End If

        For i = 0 To 4 ' this line outputs calculates the order cost 
            totalcost(i) = ordernum(i).quantity * ordernum(i).cost
        Next i

        cost = totalcost(0) + totalcost(1) + totalcost(2) + totalcost(3) + totalcost(4) ' this line stores the total cost of the orders

        'these line check if the customer has customised there drink
        If custom1.Checked = True Then
            cost = cost + 0.5
        End If
        If custom2.Checked = True Then
            cost = cost + 0.5
        End If
        If custom3.Checked = True Then
            cost = cost + 0.5
        End If
        If custom4.Checked = True Then
            cost = cost + 0.5
        End If
        If custom5.Checked = True Then
            cost = cost + 0.5
        End If

        If RadioButton1.Checked = True Then ' checks if the customer wanted delivery and if they did the address of delivery will be displayed on the recepit

            delvadd = "Collection"
        ElseIf RadioButton2.Checked = True Then
            Do
                'asks the customer for their delivery address as they have wanted their order to be delivered
                delivery = InputBox("Enter delivery address")
                If delivery = "" Then
                    MsgBox("Please enter a address")
                End If
            Loop Until delivery <> ""
            '
            delvadd = "Delivery address: " & delivery & "(" & ListBox1.Text & ")"
            cost = cost + 1
            If delvadd = "" Then
                MsgBox("Please enter if wanted for collection or delivery")
            End If
        End If



        txttotal.Text = Format(cost, "currency") ' this line formats the totalcost and outputs it to the user to see



        MsgBox("Order submitted")



        applyVAT(cost) ' the function for the VAT is used here.
        txttotal2.Text = Format(cost, "currency")
        orderline(4) = orderline(0) & " " & orderline(1) & " " & orderline(2) & " " & orderline(3) & " " & orderline(4)
        Do
            paid = InputBox("Your total after VAT is: " & Format(cost, "currency") & vbCrLf & " how much would you like to pay") ' Asks the user how much the would like to pay
            If paid = "" Then
                MsgBox("please enter the amount you want to pay ")
            End If
        Loop Until paid <> ""
        change = MsgBox("Thank you and your change is:" & Format(paid - cost, "currency")) 'this line calculates the change for the customer


        ' this line outputs the recepit to the cutomer with there name, reference number, amount paid and items ordered

        reciept = ("Customer name: " & UCase(title) & " " & UCase(Mid(fname, 1, 1) & sname) & vbCrLf & "Reference number: " & LCase(Mid(fname, 1, 1) & sname & Mid(DOB, 4, 2) & Mid(DOB, 1, 2) & vbCrLf & "Item(s) ordered: " & orderline(4) & vbCrLf & "Phone number: " & phonenum & vbCrLf & delvadd & vbCrLf & "Change due: " & Format(paid - cost, "currency")))
        Me.Hide()
        receipt.Show() 'the receipt form is opened
    End Sub

End Class