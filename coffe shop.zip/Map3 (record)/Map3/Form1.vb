﻿Public Class Form1
    Dim address, refnum, delvadd As String ' This is where I have declared the variables to capture the customers order
    Dim delivery As String
    Dim paid As String
    Dim change As String
    Dim quantity(5) As String
    Dim satisfied As Char
    Dim itemcost(5) As String
    Dim masterkey As String
    Const vat As Single = 1.2 ' I have used VAT as a constant which is 1.2 as there is 20% VAT

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load ' this is the weilcome message to the coffe shop
        MsgBox("Welcome to The Best Coffee Shop", Title:="Coffee Shop")
        Do While masterkey <> "1234"
            masterkey = InputBox("Please enter the masterkey")
            If masterkey <> "1234" Then
                MsgBox("Please enter the correct masterkey", vbExclamation)
            End If
        Loop
    End Sub


    Private Sub txtFname_LostFocus(sender As Object, e As EventArgs) Handles txtFname.LostFocus

        Fname = txtFname.Text 'these lines assign the text boxes to the varibales that are used in th
        If txtFname.Text = "" Then              'this is a presence check for the user name as it can not be left blank    
            MsgBox("Please enter a first name")
            txtFname.BackColor = Color.Red
        Else
            txtFname.BackColor = Color.Green
        End If
        lencheck(txtFname.Text, "firstname")

    End Sub
    Private Sub txtSname_LostFocusd(sender As Object, e As EventArgs) Handles txtSname.LostFocus
        Sname = txtSname.Text
        If sname = "" Then  ' this is a length check for the name of the customer as the customers name cannot exceed 15 characters
            MsgBox("field is blank")
            txtSname.BackColor = Color.Red

        Else
            txtSname.BackColor = Color.Green

        End If
        lencheck(txtSname.Text, "surname")


    End Sub

    'is a procedure that carries out a range check
    Sub lencheck(ByRef checkedfield As String, ByRef outputstring As String)
        If checkedfield.Length > 15 Then
            MsgBox(outputstring & " is too long")
        End If
    End Sub

    Private Sub txtphonenum_LostFocus(sender As Object, e As EventArgs) Handles txtphonenum.LostFocus
        If Len(txtphonenum.Text) = 11 Then           'this is a length check as the customer should only enter a phone number that is 11 digits long
            txtphonenum.BackColor = Color.Green
        Else
            txtphonenum.BackColor = Color.Red
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        fname = txtFname.Text 'these lines assign the text boxes to the varibales that are used in them
        sname = txtSname.Text
        address = txtphonenum.Text

        phonenum = txtphonenum.Text

        If RadioButton3.Checked = True Then ' these  radio buttons allow the customer to click a suitable title for them
            title = RadioButton3.Text
        End If
        If RadioButton4.Checked = True Then
            title = RadioButton4.Text
        End If
        If RadioButton5.Checked = True Then
            title = RadioButton5.Text
        End If
        If RadioButton6.Checked = True Then
            title = RadioButton6.Text
        End If



        If title <> "" Then 'checks if the customer has entered a title that is suitable for them
            MsgBox("details submitted")
            order.Show()
            Me.Hide()
        Else
            MsgBox("please click on a suitable title")
        End If

    End Sub

    Private Sub calDOB_LostFocus(sender As Object, e As EventArgs) Handles calDOB.LostFocus
        DOB = Me.calDOB.SelectionStart.ToString 'stores the users date of birth
    End Sub
End Class

